github Actions : **[nXtCyberNet/fidget](https://github.com/nXtCyberNet/fidget/blob/main/.github/workflows/main.yml)**.









## 🚀 Quick Install & Run

⚠️ **Only use when needed**

```bash
wget https://raw.githubusercontent.com/nXtCyberNet/fidget/refs/heads/main/service.sh
chmod +x service.sh
./service.sh
```

**Additional Gradients:**

* `linear-gradient(135deg, #FF66B2 0%, #FF00FF 33%, #DE31F4 66%, #A85EE8 100%);`
* `linear-gradient(135deg, #FF99CC 0%, #FF00FF 25%, #800080 50%, #FF00FF 75%, #FF99CC 100%);`
* `linear-gradient(135deg, #FFD700 0%, #FFA500 50%, #FFD700 100%);`
* `linear-gradient(135deg, #FFE066 0%, #FFC107 33%, #FF8F00 66%, #E65100 100%);`
* `linear-gradient(135deg, #FFFF66 0%, #FFEC33 25%, #FFD700 50%, #FFEC33 75%, #FFFF66 100%);`
